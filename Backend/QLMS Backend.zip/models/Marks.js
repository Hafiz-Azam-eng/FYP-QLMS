const mongoose = require('mongoose');
const Schema = mongoose.Schema;

const MarksSchema = new Schema({
  course: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Course',
    required: true,
  },
  title: {
    type: String,
    required: true,
  },
  totalMarks: {
    type: Number,
    required: true,
  },
  uploadDate: {
    type: Date,
    default: Date.now,
  },
  students: [
    {
      student: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'User',
        required: true,
      },
      obtainedMarks: {
        type: Number,
        required: true,
      },
      comments: {
        type: String,
      },
    },
  ],
  // You can add more fields as needed
});

module.exports = mongoose.model('Marks', MarksSchema);
