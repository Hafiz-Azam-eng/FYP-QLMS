const express = require('express');
const router = express.Router();
const instAuth = require('../../middleware/instAuth');
const Course = require('../../models/Course'); // Import the Course model
const Marks = require('../../models/Marks');
const auth = require('../../middleware/auth');
const {User} = require('../../models/user');


// POST route to upload or update students' marks for a specific course
router.post('/upload/:courseId', instAuth, async (req, res) => {
  try {
    const courseId = req.params.courseId;

    // Check if the instructor is the creator of the course
    const course = await Course.findById(courseId);
    if (!course || !course.instructor.equals(req.instructor)) {
      return res.status(401).json({ message: 'Unauthorized' });
    }

    const { title, totalMarks, students } = req.body;

    // Ensure obtained marks are not greater than total marks
    for (const student of students) {
      if (student.obtainedMarks > totalMarks) {
        return res.status(400).json({ message: 'Obtained marks cannot be greater than total marks' });
      }
    }

    // Find existing marks document, if any, and update it
    let marks = await Marks.findOne({ course: courseId, title });

    if (!marks) {
      // Create a new Marks instance if no existing marks found
      marks = new Marks({
        course: courseId,
        title,
        totalMarks,
        students,
      });
    } else {
      // Update the existing marks document
      marks.totalMarks = totalMarks;
      marks.students = students;
    }

    // Save the marks to the database
    await marks.save();

    res.status(200).json({ message: 'Marks uploaded successfully' });
  } catch (err) {
    console.error(err);
    res.status(500).send('Server Error');
  }
});

router.put('/edit/:marksId', instAuth, async (req, res) => {
    try {
      const marksId = req.params.marksId;
  
      // Check if the instructor is the creator of the marks
      const marks = await Marks.findById(marksId);
      if (!marks) {
        return res.status(404).json({ message: 'Marks not found' });
      }
  
      // Fetch the associated course
      const course = await Course.findById(marks.course);
      if (!course) {
        return res.status(404).json({ message: 'Course not found' });
      }
  
      // Check if the instructor is the creator of the course
      if (!course.instructor.equals(req.instructor)) {
        return res.status(401).json({ message: 'Unauthorized' });
      }
  
      const { totalMarks, students } = req.body;
  
      // Ensure obtained marks are not greater than total marks
      for (const student of students) {
        if (student.obtainedMarks > totalMarks) {
          return res.status(400).json({ message: 'Obtained marks cannot be greater than total marks' });
        }
      }
  
      // Update the marks document for the specified assignment
      marks.totalMarks = totalMarks;
      marks.students = students;
      await marks.save();
  
      res.status(200).json({ message: 'Marks updated successfully' });
    } catch (err) {
      console.error(err);
      res.status(500).send('Server Error');
    }
  });
  // GET route to retrieve marks by ID
router.get('/:marksId', instAuth, async (req, res) => {
    try {
      const marksId = req.params.marksId;
  
      // Find marks by their ID
      const marks = await Marks.findById(marksId);
  
      if (!marks) {
        return res.status(404).json({ message: 'Marks not found' });
      }
  
      res.json(marks);
    } catch (err) {
      console.error(err);
      res.status(500).send('Server Error');
    }
  });
  
  // GET route to retrieve all marks of a specific course
router.get('/course/:courseId', instAuth, async (req, res) => {
    try {
        const courseId = req.params.courseId;
        const instructorId = req.instructor;

        // Check if the instructor is the creator of the course
        const course = await Course.findById(courseId);

        if (!course || !course.instructor.equals(instructorId)) {
            return res.status(401).json({ message: 'Unauthorized' });
        }

        const marks = await Marks.find({ course: courseId });

        if (!marks) {
            return res.status(404).json({ message: 'Marks not found for the specified course' });
        }

        res.json(marks);
    } catch (err) {
        console.error(err);
        res.status(500).send('Server Error');
    }
});

  
  
  // GET route to retrieve enrolled users' information for a specific course
router.get('/enrolled/:courseId', instAuth, async (req, res) => {
    try {
      const courseId = req.params.courseId;
  
      // Check if the instructor is the creator of the course
      const course = await Course.findById(courseId);
      if (!course || !course.instructor.equals(req.instructor)) {
        return res.status(401).json({ message: 'Unauthorized' });
      }
  
      // Fetch enrolled users' information (user IDs, first names, last names, and emails)
      const enrolledUsersInfo = await User.find({ _id: { $in: course.students } }, 'firstName lastName email');
  
      res.json(enrolledUsersInfo);
    } catch (err) {
      console.error(err);
      res.status(500).send('Server Error');
    }
  });

  // GET route to retrieve marks for a specific user in a course
router.get('/user/:courseId', auth, async (req, res) => {
    try {
      const courseId = req.params.courseId;
      const userId = req.user;
  
      // Fetch marks for the specified user in the specified course
      const userMarks = await Marks.findOne({ course: courseId, 'students.student': userId });
  
      if (!userMarks) {
        return res.status(404).json({ message: 'Marks not found for the user in this course' });
      }
  
      res.json(userMarks);
    } catch (err) {
      console.error(err);
      res.status(500).send('Server Error');
    }
  });

module.exports = router;
